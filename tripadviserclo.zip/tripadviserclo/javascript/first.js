// document.write("this is my javascript")
console.log("this is consol");
var a = 10
var b = 20
var c = a + b;
console.log("this is c:" + c);
console.log("this is second console");
// document.write("i am document.write");